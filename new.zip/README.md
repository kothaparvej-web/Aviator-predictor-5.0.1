Aviator Predictor 5.0 - GitHub-ready package
============================================
This package contains the Flutter scaffold (UI) plus a GitHub Actions workflow
to build a signed Android APK automatically when you push to GitHub.

Steps to use:
1. Create a GitHub repository and push the contents of this package.
2. Go to your repo Settings -> Secrets and create the following secrets:
   - AVIATOR_KEYSTORE : base64 encoded content of your .jks file
   - KEYSTORE_PASSWORD
   - KEY_ALIAS
   - KEY_PASSWORD
3. Push to branch 'main' (or 'master') to trigger the workflow, or run manually from Actions tab.
4. After workflow finishes, download the 'aviator-apk' artifact from the workflow run.

Notes:
- Do NOT commit your keystore or passwords to the repository.
- key.properties.template is included as example.
- Replace app id / package name in android/app/build.gradle if needed.

Aviator Predictor 5.0 - Flutter project scaffold (v2)
=====================================================
This is an improved ready-to-build Flutter project scaffold containing:
- lib/main.dart : UI implementing Login (OTP+Password+admin-approval mock), Game Select, Game Inside page, Offer Page (Purple theme), Payment stub, Signal page.
- pubspec.yaml : declares dependencies.
- assets/placeholder.png : placeholder asset.
- README includes build instructions and notes for developers.

Important
- This environment cannot compile or publish APKs. To produce an APK you must build locally using Flutter SDK.
- The app uses simulated/mock backend flows. Replace the API stubs in `lib/main.dart` with real HTTP calls to your backend or Firebase.
- Admin Panel is NOT included; provide a backend and admin panel to control approvals/signals.

Build instructions:
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. cd aviator_predictor_5_v2
3. flutter pub get
4. flutter run  (to run on device/emulator)
5. flutter build apk --release (to build release APK)

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(AviatorApp());
}

class AviatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aviator Predictor 5.0',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: Color(0xFF6A0DAD),
        scaffoldBackgroundColor: Colors.black,
      ),
      home: LoginPage(),
    );
  }
}

// In-memory mock state (for demo only)
class MockAuth {
  static String? phone;
  static String? password;
  static bool approved = false;
  static bool firstTime = true;
  static int balance = 0;
  static int signalsLeft = 0;
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _phoneCtrl = TextEditingController();
  final _otpCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  bool _showPass = false;

  void _sendOtp() {
    Fluttertoast.showToast(msg: "OTP sent (mock). Use 1234");
  }

  void _signup() {
    if (_phoneCtrl.text.isEmpty) {
      Fluttertoast.showToast(msg: "Enter phone");
      return;
    }
    if (_passCtrl.text.length < 4) {
      Fluttertoast.showToast(msg: "Password min 4 chars");
      return;
    }
    MockAuth.phone = _phoneCtrl.text;
    MockAuth.password = _passCtrl.text;
    MockAuth.firstTime = false;
    MockAuth.approved = false; // require admin approval
    Fluttertoast.showToast(msg: "Signed up. Pending admin approval (mock).");
  }

  void _login() {
    if (MockAuth.phone != _phoneCtrl.text || MockAuth.password != _passCtrl.text) {
      Fluttertoast.showToast(msg: "Invalid credentials (mock)");
      return;
    }
    if (!MockAuth.approved) {
      Fluttertoast.showToast(msg: "Pending admin approval. Request sent (mock).");
      return;
    }
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => GameSelectPage()));
  }

  void _openWhatsApp() async {
    final url = Uri.parse('https://wa.me/8801905437211');
    if (await canLaunchUrl(url)) await launchUrl(url);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.symmetric(horizontal: 24),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 40),
                Image.asset('assets/placeholder.png', width: 120, height: 120),
                SizedBox(height: 12),
                Text('Aviator Predictor 5.0', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.purpleAccent)),
                SizedBox(height: 24),
                TextField(
                  controller: _phoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    hintText: 'Phone Number',
                    prefixIcon: Icon(Icons.phone),
                    filled: true,
                    fillColor: Colors.white10,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _otpCtrl,
                        decoration: InputDecoration(
                          hintText: 'OTP (mock:1234)',
                          filled: true,
                          fillColor: Colors.white10,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    SizedBox(width: 8),
                    ElevatedButton(onPressed: _sendOtp, child: Text('Send OTP'))
                  ],
                ),
                SizedBox(height: 12),
                TextField(
                  controller: _passCtrl,
                  obscureText: !_showPass,
                  decoration: InputDecoration(
                    hintText: 'Set Password (first time)',
                    prefixIcon: Icon(Icons.lock),
                    filled: true,
                    fillColor: Colors.white10,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    suffixIcon: IconButton(
                      icon: Icon(_showPass ? Icons.visibility_off : Icons.visibility),
                      onPressed: () => setState(() => _showPass = !_showPass),
                    ),
                  ),
                ),
                SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: ElevatedButton(onPressed: _signup, child: Text('Sign Up'))),
                    SizedBox(width: 8),
                    Expanded(child: OutlinedButton(onPressed: _login, child: Text('Sign In'))),
                  ],
                ),
                SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: _openWhatsApp,
                  icon: Icon(Icons.whatsapp),
                  label: Text('Customer Service (WhatsApp)'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                ),
                SizedBox(height: 8),
                Text('One device per user. New devices require admin approval (mock).', textAlign: TextAlign.center),
                SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class GameSelectPage extends StatelessWidget {
  final games = [
    {'title': 'Aviator', 'icon': '🛩'},
    {'title': 'JetX', 'icon': '🚀'},
    {'title': 'Crash', 'icon': '💥'},
    {'title': 'Jetflix', 'icon': '🎬'},
    {'title': 'Mines', 'icon': '💣'},
    {'title': 'Double', 'icon': '2x'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Row(
          children: [
            Text('💰 ৳' + MockAuth.balance.toString(), style: TextStyle(fontWeight: FontWeight.bold)),
            Spacer(),
            Icon(Icons.notifications),
            SizedBox(width: 8),
            CircleAvatar(child: Icon(Icons.person))
          ],
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(12),
        child: GridView.count(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          children: games.map((g) {
            return GestureDetector(
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => GameInsidePage(gameTitle: g['title']!)));
              },
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.white10, Colors.white12]),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Colors.purpleAccent, width: 2),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(g['icon']!, style: TextStyle(fontSize: 40)),
                    SizedBox(height: 8),
                    Text(g['title']!, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}

class GameInsidePage extends StatelessWidget {
  final String gameTitle;
  GameInsidePage({required this.gameTitle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(gameTitle)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(12), border: Border.all(color: Colors.red, width: 3)),
              child: Column(
                children: [
                  Text('আপনি যে গেমটি খেলবেন সেটি সিলেক্ট করুন', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _smallCard('Aviator'),
                      _smallCard('Crash'),
                      _smallCard('JetX'),
                    ],
                  )
                ],
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => OfferPage(game: gameTitle)));
              },
              child: Text('Next → Offers'),
            )
          ],
        ),
      ),
    );
  }

  Widget _smallCard(String title) {
    return Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), color: Colors.white12, border: Border.all(color: Colors.white24)),
      child: Center(child: Text(title, style: TextStyle(fontWeight: FontWeight.bold))),
    );
  }
}

class OfferPage extends StatelessWidget {
  final String game;
  OfferPage({required this.game});

  void _openPayment(BuildContext context, int amount) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => PaymentPage(amount: amount, game: game)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('$game Offers'), backgroundColor: Colors.black87),
      body: Container(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(color: Color(0x11000000), borderRadius: BorderRadius.circular(12)),
              child: Text('💜 আপনার পছন্দের অফারটি সিলেক্ট করুন', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 12),
            Expanded(
              child: ListView(
                children: [
                  _offerCard(context, 'Day Offer', 'সকাল ৮টা – বিকাল ৫টা', 15),
                  SizedBox(height: 12),
                  _offerCard(context, 'Night Premium Offer', 'সন্ধ্যা ৬টা – রাত ৩টা', 20),
                  SizedBox(height: 12),
                  _oneTimeCard(context, 'One Time Signal', '1 সিগন্যাল', 5),
                  SizedBox(height: 18),
                  ElevatedButton(
                    onPressed: () => _openPayment(context, 1500),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 14.0, horizontal: 12),
                      child: Text('💳 Direct Payment করুন (Min 1500)', style: TextStyle(fontSize: 16)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color(0xFF6A0DAD),
        onPressed: () async {
          final url = Uri.parse('https://wa.me/8801905437211');
          if (await canLaunchUrl(url)) await launchUrl(url);
        },
        child: Icon(Icons.whatsapp),
      ),
    );
  }

  Widget _offerCard(BuildContext context, String title, String subtitle, int price) {
    return GestureDetector(
      onTap: () => _openPayment(context, price),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Color(0xFF0D0014),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            width: 2,
            color: Colors.purpleAccent,
          ),
          boxShadow: [BoxShadow(color: Colors.purple.withOpacity(0.2), blurRadius: 12, spreadRadius: 1)],
        ),
        child: Row(
          children: [
            Container(width: 80, height: 80, decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(12)), child: Icon(Icons.star, size: 36, color: Colors.purpleAccent)),
            SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 6),
                Text(subtitle),
                SizedBox(height: 6),
                Text('৳$price', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              ]),
            ),
            ElevatedButton(onPressed: () => _openPayment(context, price), child: Text('Select'))
          ],
        ),
      ),
    );
  }

  Widget _oneTimeCard(BuildContext context, String title, String subtitle, int price) {
    return GestureDetector(
      onTap: () => _openPayment(context, price),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Color(0xFF1A0018),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(width: 2, color: Colors.redAccent),
          boxShadow: [BoxShadow(color: Colors.red.withOpacity(0.16), blurRadius: 12, spreadRadius: 1)],
        ),
        child: Row(
          children: [
            Container(width: 80, height: 80, decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(12)), child: Icon(Icons.fiber_manual_record, size: 36, color: Colors.redAccent)),
            SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(height: 6),
                Text(subtitle),
                SizedBox(height: 6),
                Text('৳$price', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
              ]),
            ),
            ElevatedButton(onPressed: () => _openPayment(context, price), child: Text('Select'))
          ],
        ),
      ),
    );
  }
}

class PaymentPage extends StatefulWidget {
  final int amount;
  final String game;
  PaymentPage({required this.amount, required this.game});
  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  final _trxCtrl = TextEditingController();
  int _amount = 0;
  String _method = 'bKash';

  @override
  void initState() {
    super.initState();
    _amount = widget.amount;
  }

  void _submitPayment() {
    if (_amount < 500 && MockAuth.firstTime) {
      Fluttertoast.showToast(msg: "First deposit must be at least ৳500");
      return;
    }
    if (!MockAuth.firstTime && _amount < 1500) {
      Fluttertoast.showToast(msg: "Subsequent deposits must be at least ৳1500");
      return;
    }
    Fluttertoast.showToast(msg: "Payment submitted (mock). Waiting admin approval.");
    // For demo, simulate approve and add
    MockAuth.balance += _amount;
    MockAuth.approved = true;
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SignalPage(game: widget.game)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Payment'), backgroundColor: Colors.black87),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Receiver: 01905437211', style: TextStyle(fontSize: 16)),
            SizedBox(height: 12),
            DropdownButton<String>(
              value: _method,
              items: ['bKash', 'Nagad', 'Rocket'].map((m) => DropdownMenuItem(child: Text(m), value: m)).toList(),
              onChanged: (v) => setState(() => _method = v!),
            ),
            SizedBox(height: 12),
            TextField(
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Amount', border: OutlineInputBorder()),
              controller: TextEditingController(text: _amount.toString()),
              onChanged: (v) => _amount = int.tryParse(v) ?? _amount,
            ),
            SizedBox(height: 12),
            TextField(controller: _trxCtrl, decoration: InputDecoration(labelText: 'Transaction ID (optional)', border: OutlineInputBorder())),
            SizedBox(height: 12),
            ElevatedButton(onPressed: _submitPayment, child: Text('Submit Payment')),
          ],
        ),
      ),
    );
  }
}

class SignalPage extends StatefulWidget {
  final String game;
  SignalPage({required this.game});
  @override
  _SignalPageState createState() => _SignalPageState();
}

class _SignalPageState extends State<SignalPage> {
  List<String> signals = [];
  @override
  void initState() {
    super.initState();
    signals = ['UP', 'DOWN', 'UP'];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.game} Signals')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Live Signals', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: signals.length,
                itemBuilder: (_, i) => Card(
                  color: Colors.white10,
                  child: ListTile(
                    title: Text(signals[i], style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  ),
                ),
              ),
            ),
            ElevatedButton(onPressed: () {
              Fluttertoast.showToast(msg: 'Mock: Admin sent signal UP');
              setState(() => signals.insert(0, 'UP'));
            }, child: Text('Mock: Receive Signal')),
          ],
        ),
      ),
    );
  }
}
